﻿#pragma warning disable 1591

namespace Apex.Examples.AI.Tutorial
{
    using Apex.AI;
    using Apex.Serialization;
    using UnityEngine;

    public sealed class ScanForPositions : ActionBase
    {
        [ApexSerialization, FriendlyName("Sampling Range", "How large a range points are sampled in, in a square with the entity in the center")]
        public float samplingRange = 12f;

        [ApexSerialization, FriendlyName("Sampling Density", "How much distance there is between individual point samples")]
        public float samplingDensity = 1.5f;

        public override void Execute(IAIContext context)
        {
            var c = (ExampleContext)context;

            // clear any previously sampled positions
            c.sampledPositions.Clear();

            var halfSamplingRange = this.samplingRange * 0.5f;
            var pos = c.self.transform.position;

            // could also be exposed directly by the Context
            var navMeshAgent = c.self.GetComponent<NavMeshAgent>();

            // nested loop in x and z directions, starting at negative half sampling range and ending at positive half sampling range, thus sampling in a square around the entity
            for (var x = -halfSamplingRange; x < halfSamplingRange; x += this.samplingDensity)
            {
                for (var z = -halfSamplingRange; z < halfSamplingRange; z += this.samplingDensity)
                {
                    var p = new Vector3(pos.x + x, 0f, pos.z + z);

                    // Sample the position in the navigation mesh to ensure that the desired position is actually walkable
                    NavMeshHit hit;
                    if (NavMesh.SamplePosition(p, out hit, this.samplingDensity * 0.5f, navMeshAgent.walkableMask))
                    {
                        // only walkable positions are added to the list
                        c.sampledPositions.Add(hit.position);
                    }
                }
            }
        }
    }
}