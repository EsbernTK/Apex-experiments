﻿#pragma warning disable 1591

namespace Apex.Examples.AI
{
    public enum RangeOperator
    {
        None = 0,
        LessThan,
        LessThanOrEquals,
        Equals,
        GreaterThanOrEquals,
        GreaterThan
    }
}